# NikomConnect98
For the Swedish BBS-system Nikom. A new version supporting the year 2000.
